import os
IMAGE_FILES = os.listdir('test')

f = open('test.txt', 'w')
print(IMAGE_FILES)
for item in IMAGE_FILES:
    #item=item.replace('txt','jpg')
    f.write('./images/'+item+'\n')
f.close()
